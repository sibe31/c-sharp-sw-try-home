using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
using System.Runtime.InteropServices;
using System;

namespace OpenPartEditCreateDwg.csproj
{
    public partial class SolidWorksMacro
    {


        public void Main()
        {

            
            ModelDoc2 swDoc = null;
            PartDoc swPart = null;
            DrawingDoc swDrawing = null;
            AssemblyDoc swAssembly = null;
            bool boolstatus = false;
            int longstatus = 0;
            int longwarnings = 0;
            // 
            // Open
            swDoc = ((ModelDoc2)(swApp.OpenDoc6("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\03. 06.12.2018\\CylTry1.SLDPRT", 1, 0, "", ref longstatus, ref longwarnings)));
            swApp.ActivateDoc2("CylTry1", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            ModelView myModelView = null;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameLeft = 0;
            myModelView.FrameTop = 0;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            boolstatus = swDoc.Extension.SelectByID2("Sketch1", "SKETCH", 0, 0, 0, false, 0, null, 0);
            swDoc.EditSketch();
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("D1@Sketch1@CylTry1.SLDPRT", "DIMENSION", 0.035564372989716819, 0.010312739703457967, -0.0087885270330612143, false, 0, null, 0);
            boolstatus = swDoc.Extension.SelectByID2("D1@Sketch1@CylTry1.SLDPRT", "DIMENSION", 0.035564372989716819, 0.010312739703457967, -0.0087885270330612143, false, 0, null, 0);
            boolstatus = swDoc.Extension.SelectByID2("D1@Sketch1@CylTry1.SLDPRT", "DIMENSION", 0.035564372989716819, 0.010312739703457967, -0.0087885270330612143, false, 0, null, 0);
            swDoc.SketchManager.InsertSketch(true);
            boolstatus = swDoc.Extension.SelectByID2("Boss-Extrude1", "BODYFEATURE", 0, 0, 0, false, 0, null, 0);
            swDoc.ClearSelection2(true);
            swDoc.ISelectionManager.EnableContourSelection = false;
            swDoc.ClearSelection2(true);
            // 
            // Close Document
            swPart = null;
            swDoc = null;
            swApp.CloseDoc("CylTry1");
            // 
            // Open
            swDoc = ((ModelDoc2)(swApp.OpenDoc6("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\03. 06.12.2018\\CylTry1.SLDPRT", 1, 0, "", ref longstatus, ref longwarnings)));
            swApp.ActivateDoc2("CylTry1", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameLeft = 0;
            myModelView.FrameTop = 0;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            boolstatus = swDoc.Extension.SelectByID2("Sketch1", "SKETCH", 0, 0, 0, false, 0, null, 0);
            swDoc.EditSketch();
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("D1@Sketch1@CylTry1.SLDPRT", "DIMENSION", 0.035813813117931886, 0.010377584119778238, -0.0089642075284903332, false, 0, null, 0);
            swDoc.SketchManager.InsertSketch(true);
            boolstatus = swDoc.Extension.SelectByID2("Boss-Extrude1", "BODYFEATURE", 0, 0, 0, false, 0, null, 0);
            swDoc.ClearSelection2(true);
            swDoc.ISelectionManager.EnableContourSelection = false;
            boolstatus = swDoc.EditRebuild3();
            swDoc.ClearSelection2(true);
            // 
            // Save As
            longstatus = swDoc.SaveAs3("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\03. 06.12.2018\\CylTry1_SaveAs.SLDPRT", 0, 2);
            // 
            // New Document
            double swSheetWidth;
            swSheetWidth = 0.41999999999999998;
            double swSheetHeight;
            swSheetHeight = 0.29699999999999999;
            swDoc = ((ModelDoc2)(swApp.NewDocument("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\templates\\Drawing.drwdot", 12, swSheetWidth, swSheetHeight)));
            swDrawing = swDoc;
            swDrawing = swDoc;
            object swSheet = null;
            swSheet = swDrawing.GetCurrentSheet();
            swSheet.SetProperties2(12, 12, 1, 1, false, swSheetWidth, swSheetHeight, true);
            swSheet.SetTemplateName("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\lang\\english\\sheetformat\\a3 - iso.slddr" +
                    "t");
            swSheet.ReloadTemplate(true);
            swPart = ((PartDoc)(swDoc));
            boolstatus = swPart.GenerateViewPaletteViews("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\03. 06.12.2018\\CylTry1_SaveAs.SLDPRT");
            swDrawing = ((DrawingDoc)(swDoc));
            boolstatus = swDrawing.Create3rdAngleViews("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\03. 06.12.2018\\CylTry1_SaveAs.SLDPRT");
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Save As
            longstatus = swDoc.SaveAs3("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\03. 06.12.2018\\CylTry1_SaveAs.SLDDRW", 0, 2);
            boolstatus = swDoc.Extension.SelectByID2("Sheet1", "SHEET", 0.20488852643419564, 0.098577941507311556, 0, false, 0, null, 0);
            swDoc.ClearSelection2(true);
            // 
            // Close Document
            swDrawing = null;
            swDoc = null;
            swApp.CloseDoc("CylTry1_SaveAs - Sheet1");
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameLeft = 0;
            myModelView.FrameTop = 0;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            swApp.ActivateDoc2("CylTry1_SaveAs", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            // 
            // Close Document
            swPart = null;
            swDoc = null;
            swApp.CloseDoc("CylTry1_SaveAs");
        }

        /// <summary>
        ///  The SldWorks swApp variable is pre-assigned for you.
        /// </summary>
        public SldWorks swApp;
    }
}


