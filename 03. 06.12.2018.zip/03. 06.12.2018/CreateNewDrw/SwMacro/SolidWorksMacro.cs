using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
using System.Runtime.InteropServices;
using System;

namespace CreateNewDrw.csproj
{
    public partial class SolidWorksMacro
    {


        public void Main()
        {

            
            ModelDoc2 swDoc = null;
            PartDoc swPart = null;
            DrawingDoc swDrawing = null;
            AssemblyDoc swAssembly = null;
            bool boolstatus = false;
            int longstatus = 0;
            int longwarnings = 0;
            // 
            // New Document
            double swSheetWidth;
            swSheetWidth = 0.41999999999999998;
            double swSheetHeight;
            swSheetHeight = 0.29699999999999999;
            swDoc = ((ModelDoc2)(swApp.NewDocument("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\templates\\Drawing.drwdot", 12, swSheetWidth, swSheetHeight)));
            swDrawing = swDoc;
            swDrawing = swDoc;
            object swSheet = null;
            swSheet = swDrawing.GetCurrentSheet();
            swSheet.SetProperties2(12, 12, 1, 1, false, swSheetWidth, swSheetHeight, true);
            swSheet.SetTemplateName("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\lang\\english\\sheetformat\\a3 - iso.slddr" +
                    "t");
            swSheet.ReloadTemplate(true);
            swApp.ActivateDoc2("Draw1 - Sheet1", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            // 
            // Close Document
            swDrawing = null;
            swDoc = null;
            swApp.CloseDoc("Draw1 - Sheet1");
            // 
            // New Document
            swSheetWidth = 0.41999999999999998;
            swSheetHeight = 0.29699999999999999;
            swDoc = ((ModelDoc2)(swApp.NewDocument("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\templates\\Drawing.drwdot", 12, swSheetWidth, swSheetHeight)));
            swDrawing = swDoc;
            swDrawing = swDoc;
            swSheet = swDrawing.GetCurrentSheet();
            swSheet.SetProperties2(12, 12, 1, 1, false, swSheetWidth, swSheetHeight, true);
            swSheet.SetTemplateName("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\lang\\english\\sheetformat\\a3 - iso.slddr" +
                    "t");
            swSheet.ReloadTemplate(true);
            swApp.ActivateDoc2("Draw2 - Sheet1", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            swDrawing = ((DrawingDoc)(swDoc));
            boolstatus = swDrawing.Create3rdAngleViews("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\03. 06.12.2018\\CylTry1.SLDPRT");
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Save As
            longstatus = swDoc.SaveAs3("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\03. 06.12.2018\\CylTry1.SLDDRW", 0, 2);
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Save
            int swErrors;
            int swWarnings;
            boolstatus = swDoc.Save3(1, swErrors, swWarnings);
            // 
            // Close Document
            swDrawing = null;
            swDoc = null;
            swApp.CloseDoc("CylTry1 - Sheet1");
        }

        /// <summary>
        ///  The SldWorks swApp variable is pre-assigned for you.
        /// </summary>
        public SldWorks swApp;
    }
}


