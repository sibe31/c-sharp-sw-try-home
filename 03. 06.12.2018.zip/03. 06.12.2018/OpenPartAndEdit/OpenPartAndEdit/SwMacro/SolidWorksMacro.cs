using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
using System.Runtime.InteropServices;
using System;

namespace OpenPartAndEdit.csproj
{
    public partial class SolidWorksMacro
    {


        public void Main()
        {

            
            ModelDoc2 swDoc = null;
            PartDoc swPart = null;
            DrawingDoc swDrawing = null;
            AssemblyDoc swAssembly = null;
            bool boolstatus = false;
            int longstatus = 0;
            int longwarnings = 0;
            // 
            // Open
            swDoc = ((ModelDoc2)(swApp.OpenDoc6("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\03. 06.12.2018\\CylTry1.SLDPRT", 1, 0, "", ref longstatus, ref longwarnings)));
            swApp.ActivateDoc2("CylTry1", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            ModelView myModelView = null;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameLeft = 0;
            myModelView.FrameTop = 0;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            boolstatus = swDoc.Extension.SelectByID2("Sketch1", "SKETCH", 0, 0, 0, false, 0, null, 0);
            swDoc.EditSketch();
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("D1@Sketch1@CylTry1.SLDPRT", "DIMENSION", 0.0426675019519175, 0.0044012003818499276, -0.027881805266583608, false, 0, null, 0);
            swDoc.SketchManager.InsertSketch(true);
            boolstatus = swDoc.Extension.SelectByID2("Boss-Extrude1", "BODYFEATURE", 0, 0, 0, false, 0, null, 0);
            swDoc.ClearSelection2(true);
            swDoc.ISelectionManager.EnableContourSelection = false;
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            boolstatus = swDoc.EditRebuild3();
            swDoc.ClearSelection2(true);
            // 
            // Save
            int swErrors;
            int swWarnings;
            boolstatus = swDoc.Save3(1, swErrors, swWarnings);
            // 
            // Close Document
            swPart = null;
            swDoc = null;
            swApp.CloseDoc("CylTry1");
        }

        /// <summary>
        ///  The SldWorks swApp variable is pre-assigned for you.
        /// </summary>
        public SldWorks swApp;
    }
}


