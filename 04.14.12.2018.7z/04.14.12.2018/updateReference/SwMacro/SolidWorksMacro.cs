using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
using System.Runtime.InteropServices;
using System;

namespace updateReference.csproj
{
    public partial class SolidWorksMacro
    {


        public void Main()
        {

            
            ModelDoc2 swDoc = null;
            PartDoc swPart = null;
            DrawingDoc swDrawing = null;
            AssemblyDoc swAssembly = null;
            bool boolstatus = false;
            int longstatus = 0;
            int longwarnings = 0;
            // 
            // Open
            swDoc = ((ModelDoc2)(swApp.OpenDoc6("C:\\Users\\SIBERAJA\\Desktop\\New folder\\1.SLDDRW", 3, 0, "", ref longstatus, ref longwarnings)));
            swDrawing = swDoc;
            swApp.ActivateDoc2("1 - Sheet1", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            ModelView myModelView = null;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameLeft = 0;
            myModelView.FrameTop = 0;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Save
            int swErrors;
            int swWarnings;
            boolstatus = swDoc.Save3(1, swErrors, swWarnings);
            // 
            // Close Document
            swDrawing = null;
            swDoc = null;
            swApp.CloseDoc("1 - Sheet1");
        }

        /// <summary>
        ///  The SldWorks swApp variable is pre-assigned for you.
        /// </summary>
        public SldWorks swApp;
    }
}


