using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
using System.Runtime.InteropServices;
using System;

namespace MacroTry2.csproj
{
    public partial class SolidWorksMacro
    {


        public void Main()
        {

            
            ModelDoc2 swDoc = null;
            PartDoc swPart = null;
            DrawingDoc swDrawing = null;
            AssemblyDoc swAssembly = null;
            bool boolstatus = false;
            int longstatus = 0;
            int longwarnings = 0;
            // 
            // New Document
            double swSheetWidth;
            swSheetWidth = 0;
            double swSheetHeight;
            swSheetHeight = 0;
            swDoc = ((ModelDoc2)(swApp.NewDocument("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\templates\\Part.prtdot", 0, swSheetWidth, swSheetHeight)));
            swPart = swDoc;
            swApp.ActivateDoc2("Part2", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            ModelView myModelView = null;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            boolstatus = swDoc.Extension.SelectByID2("Top Plane", "PLANE", 0, 0, 0, false, 0, null, 0);
            swDoc.SketchManager.InsertSketch(true);
            swDoc.ClearSelection2(true);
            SketchSegment skSegment = null;
            skSegment = ((SketchSegment)(swDoc.SketchManager.CreateCircle(0, 0, 0, 0.037499, -0.000388, 0)));
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("Arc1", "SKETCHSEGMENT", 0.031033990967435254, 0, -0.022111718564297597, false, 0, null, 0);
            DisplayDimension myDisplayDim = null;
            myDisplayDim = ((DisplayDimension)(swDoc.AddDimension2(0.049137152365105796, 0, -0.043576895650106959)));
            swDoc.ClearSelection2(true);
            Dimension myDimension = null;
            myDimension = ((Dimension)(swDoc.Parameter("D1@Sketch1")));
            myDimension.SystemValue = 0.05;
            swDoc.ClearSelection2(true);
            // 
            // Named View
            swDoc.ShowNamedView2("*Trimetric", 8);
            swDoc.ViewZoomtofit2();
            Feature myFeature = null;
            myFeature = ((Feature)(swDoc.FeatureManager.FeatureExtrusion2(true, false, false, 0, 0, 0.03, 0.01, false, false, false, false, 0.017453292519943334, 0.017453292519943334, false, false, false, false, true, true, true, 0, 0, false)));
            swDoc.ISelectionManager.EnableContourSelection = false;
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("Unknown", "BROWSERITEM", 0, 0, 0, false, 0, null, 0);
            swDoc.ClearSelection2(true);
            swPart = ((PartDoc)(swDoc));
            swPart.SetMaterialPropertyName2("Default", "C:/Program Files/SOLIDWORKS Corp/SOLIDWORKS/lang/english/sldmaterials/SOLIDWORKS " +
                    "Materials.sldmat", "Plain Carbon Steel");
            // 
            // Save As
            longstatus = swDoc.SaveAs3("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\Part2.SLDPRT", 0, 2);
            boolstatus = swDoc.EditRebuild3();
            swDoc.ClearSelection2(true);
            // 
            // Save
            int swErrors;
            int swWarnings;
            boolstatus = swDoc.Save3(1, swErrors, swWarnings);
            // 
            // New Document
            swSheetWidth = 0.41999999999999998;
            swSheetHeight = 0.29699999999999999;
            swDoc = ((ModelDoc2)(swApp.NewDocument("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\templates\\Drawing.drwdot", 12, swSheetWidth, swSheetHeight)));
            swDrawing = swDoc;
            swDrawing = swDoc;
            object swSheet = null;
            swSheet = swDrawing.GetCurrentSheet();
            swSheet.SetProperties2(12, 12, 1, 1, false, swSheetWidth, swSheetHeight, true);
            swSheet.SetTemplateName("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\lang\\english\\sheetformat\\a3 - iso.slddr" +
                    "t");
            swSheet.ReloadTemplate(true);
            swPart = ((PartDoc)(swDoc));
            boolstatus = swPart.GenerateViewPaletteViews("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\Part2.SLDPRT");
            View myView = null;
            swDrawing = ((DrawingDoc)(swDoc));
            myView = ((View)(swDrawing.DropDrawingViewFromPalette2("Drawing View1", 0.12169329599297549, 0.17981233940623489, 0)));
            boolstatus = swDoc.Extension.SelectByID2("Drawing View1", "DRAWINGVIEW", 0, 0, 0, false, 0, null, 0);
            swDrawing = ((DrawingDoc)(swDoc));
            myView = ((View)(swDrawing.CreateUnfoldedViewAt3(0, 0, 0, false)));
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("Drawing View1", "DRAWINGVIEW", 0, 0, 0, false, 0, null, 0);
            swDrawing = ((DrawingDoc)(swDoc));
            boolstatus = swDrawing.ActivateView("Drawing View1");
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("Drawing View1", "DRAWINGVIEW", 0.12169329599297549, 0.17981233940623489, 0, false, 0, null, 0);
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("Drawing View1", "DRAWINGVIEW", 0.062624481571818963, 0.19741562847214245, 0, false, 0, null, 0);
            swDrawing = ((DrawingDoc)(swDoc));
            myView = ((View)(swDrawing.CreateUnfoldedViewAt3(0, 0, 0, false)));
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("Drawing View1", "DRAWINGVIEW", 0.062624481571818963, 0.19741562847214245, 0, false, 0, null, 0);
            swDrawing = ((DrawingDoc)(swDoc));
            myView = ((View)(swDrawing.CreateUnfoldedViewAt3(0, 0, 0, false)));
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("Drawing View1", "DRAWINGVIEW", 0.062624481571818963, 0.19741562847214245, 0, false, 0, null, 0);
            swDoc.ClearSelection2(true);
            swDrawing = ((DrawingDoc)(swDoc));
            boolstatus = swDrawing.ActivateView("Drawing View2");
            boolstatus = swDoc.Extension.SelectByRay(0.030630785084478862, -0.025383517859938202, 250.01975952305287, 0, 0, -1, 0.0021276918186310914, 2, false, 0, 0);
            swDrawing = ((DrawingDoc)(swDoc));
            boolstatus = swDrawing.ActivateView("Drawing View2");
            swDrawing = ((DrawingDoc)(swDoc));
            myView = ((View)(swDrawing.ActiveDrawingView));
            myView.FocusLocked = ((bool)(true));
            swDoc.EditDelete();
            swDrawing = ((DrawingDoc)(swDoc));
            boolstatus = swDrawing.ActivateView("Drawing View3");
            boolstatus = swDoc.Extension.SelectByRay(0.050656119848065562, -0.023506142725852081, 250, 0, 0, -1, 0.0021276918186310914, 46, false, 0, 0);
            boolstatus = swDoc.Extension.SelectByID2("Drawing View3", "DRAWINGVIEW", 0.045023994445806792, -0.033518810109391173, 0, false, 0, null, 0);
            swDoc.EditDelete();
            swDrawing = ((DrawingDoc)(swDoc));
            boolstatus = swDrawing.ActivateView("Drawing View4");
            boolstatus = swDoc.Extension.SelectByID2("Drawing View4", "DRAWINGVIEW", 0.054410870116238075, -0.027886684707132403, 0, false, 0, null, 0);
            swDoc.EditDelete();
            swDrawing = ((DrawingDoc)(swDoc));
            boolstatus = swDrawing.ActivateView("Drawing View1");
            boolstatus = swDoc.Extension.SelectByID2("Drawing View1", "DRAWINGVIEW", 0.17456287869775861, 0.22743633352859857, 0, false, 0, null, 0);
            swDrawing = ((DrawingDoc)(swDoc));
            boolstatus = swDrawing.Create3rdAngleViews("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\Part2.SLDPRT");
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("Drawing View1", "DRAWINGVIEW", 0.15391175222280978, 0.26310646107623747, 0, false, 0, null, 0);
            swDoc.EditDelete();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Save As
            longstatus = swDoc.SaveAs3("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\Part2.SLDDRW", 0, 2);
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Save
            boolstatus = swDoc.Save3(1, swErrors, swWarnings);
            // 
            // Close Document
            swDrawing = null;
            swDoc = null;
            swApp.CloseDoc("Part2 - Sheet1");
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameLeft = 0;
            myModelView.FrameTop = 0;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            swApp.ActivateDoc2("Part2", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            boolstatus = swDoc.EditRebuild3();
            // 
            // Save
            boolstatus = swDoc.Save3(1, swErrors, swWarnings);
            // 
            // Close Document
            swPart = null;
            swDoc = null;
            swApp.CloseDoc("Part2");
        }

        /// <summary>
        ///  The SldWorks swApp variable is pre-assigned for you.
        /// </summary>
        public SldWorks swApp;
    }
}


