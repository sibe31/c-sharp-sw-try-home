using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
using System.Runtime.InteropServices;
using System;

namespace MacroTry4.csproj
{
    public partial class SolidWorksMacro
    {


        public void Main()
        {

            
            ModelDoc2 swDoc = null;
            PartDoc swPart = null;
            DrawingDoc swDrawing = null;
            AssemblyDoc swAssembly = null;
            bool boolstatus = false;
            int longstatus = 0;
            int longwarnings = 0;
            // 
            // New Document
            double swSheetWidth;
            swSheetWidth = 0;
            double swSheetHeight;
            swSheetHeight = 0;
            swDoc = ((ModelDoc2)(swApp.NewDocument("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\templates\\Part.prtdot", 0, swSheetWidth, swSheetHeight)));
            swPart = swDoc;
            swApp.ActivateDoc2("Part1", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            ModelView myModelView = null;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            boolstatus = swDoc.Extension.SelectByID2("Top Plane", "PLANE", 0, 0, 0, false, 0, null, 0);
            swDoc.SketchManager.InsertSketch(true);
            swDoc.ClearSelection2(true);
            SketchSegment skSegment = null;
            skSegment = ((SketchSegment)(swDoc.SketchManager.CreateCircle(0, 0, 0, 0.067758, 0.000129, 0)));
            swDoc.ClearSelection2(true);
            swDoc.ClearSelection2(true);
            swDoc.SketchManager.InsertSketch(true);
            swDoc.EditUndo2(3);
            // 
            // Close Document
            swPart = null;
            swDoc = null;
            swApp.CloseDoc("Part1");
            // 
            // New Document
            swSheetWidth = 0;
            swSheetHeight = 0;
            swDoc = ((ModelDoc2)(swApp.NewDocument("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\templates\\Part.prtdot", 0, swSheetWidth, swSheetHeight)));
            swPart = swDoc;
            swApp.ActivateDoc2("Part2", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            boolstatus = swDoc.Extension.SelectByID2("Top Plane", "PLANE", 0, 0, 0, false, 0, null, 0);
            swDoc.SketchManager.InsertSketch(true);
            swDoc.ClearSelection2(true);
            skSegment = ((SketchSegment)(swDoc.SketchManager.CreateCircle(0, 0, 0, 0.034396, 0.000647, 0)));
            swDoc.ClearSelection2(true);
            boolstatus = swDoc.Extension.SelectByID2("Arc1", "SKETCHSEGMENT", 0.029740908010458811, 0, -0.020042785833135249, false, 0, null, 0);
            DisplayDimension myDisplayDim = null;
            myDisplayDim = ((DisplayDimension)(swDoc.AddDimension2(0.052499168053244616, 0, -0.039956263370572842)));
            swDoc.ClearSelection2(true);
            Dimension myDimension = null;
            myDimension = ((Dimension)(swDoc.Parameter("D1@Sketch1")));
            myDimension.SystemValue = 0.05;
            // 
            // Named View
            swDoc.ShowNamedView2("*Trimetric", 8);
            swDoc.ViewZoomtofit2();
            Feature myFeature = null;
            myFeature = ((Feature)(swDoc.FeatureManager.FeatureExtrusion2(true, false, false, 0, 0, 0.03, 0.01, false, false, false, false, 0.017453292519943334, 0.017453292519943334, false, false, false, false, true, true, true, 0, 0, false)));
            swDoc.ISelectionManager.EnableContourSelection = false;
            boolstatus = swDoc.Extension.SelectByID2("Unknown", "BROWSERITEM", 0, 0, 0, false, 0, null, 0);
            swDoc.ClearSelection2(true);
            swPart = ((PartDoc)(swDoc));
            swPart.SetMaterialPropertyName2("Default", "C:/Program Files/SOLIDWORKS Corp/SOLIDWORKS/lang/english/sldmaterials/SOLIDWORKS " +
                    "Materials.sldmat", "Plain Carbon Steel");
            boolstatus = swDoc.EditRebuild3();
            swDoc.ClearSelection2(true);
            // 
            // Save As
            longstatus = swDoc.SaveAs3("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\SwMacroPartTry4.SLDPRT", 0, 2);
            // 
            // New Document
            swSheetWidth = 0.41999999999999998;
            swSheetHeight = 0.29699999999999999;
            swDoc = ((ModelDoc2)(swApp.NewDocument("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\templates\\Drawing.drwdot", 12, swSheetWidth, swSheetHeight)));
            swDrawing = swDoc;
            swDrawing = swDoc;
            object swSheet = null;
            swSheet = swDrawing.GetCurrentSheet();
            swSheet.SetProperties2(12, 12, 1, 1, false, swSheetWidth, swSheetHeight, true);
            swSheet.SetTemplateName("C:\\ProgramData\\SolidWorks\\SOLIDWORKS 2017\\lang\\english\\sheetformat\\a3 - iso.slddr" +
                    "t");
            swSheet.ReloadTemplate(true);
            swPart = ((PartDoc)(swDoc));
            boolstatus = swPart.GenerateViewPaletteViews("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\SwMacroPartTry4.SLDPRT");
            swDrawing = ((DrawingDoc)(swDoc));
            boolstatus = swDrawing.Create3rdAngleViews("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\SwMacroPartTry4.SLDPRT");
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Zoom To Fit
            swDoc.ViewZoomtofit2();
            // 
            // Save As
            longstatus = swDoc.SaveAs3("C:\\Users\\SIBERAJA\\Desktop\\SW Check\\SwMacroPartTry4.SLDDRW", 0, 2);
            // 
            // Save
            int swErrors;
            int swWarnings;
            boolstatus = swDoc.Save3(1, swErrors, swWarnings);
            // 
            // Close Document
            swDrawing = null;
            swDoc = null;
            swApp.CloseDoc("SwMacroPartTry4 - Sheet1");
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameLeft = 0;
            myModelView.FrameTop = 0;
            myModelView = ((ModelView)(swDoc.ActiveView));
            myModelView.FrameState = ((int)(swWindowState_e.swWindowMaximized));
            swApp.ActivateDoc2("SwMacroPartTry4", false, ref longstatus);
            swDoc = ((ModelDoc2)(swApp.ActiveDoc));
            // 
            // Close Document
            swPart = null;
            swDoc = null;
            swApp.CloseDoc("SwMacroPartTry4");
        }

        /// <summary>
        ///  The SldWorks swApp variable is pre-assigned for you.
        /// </summary>
        public SldWorks swApp;
    }
}


